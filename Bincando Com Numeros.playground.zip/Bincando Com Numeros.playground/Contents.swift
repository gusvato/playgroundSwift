//: Playground - noun: a place where people can play

import UIKit
print("Exercício 1")
Exercicio01()
print("Exercício 2")
Exercicio02()
print("Exercício 3")
Exercicio03()
print("Exercício 4")
Exercicio04()
print("Exercício 5")
Exercicio05()
print("Exercício 6")
Exercicio06()
print("Tabuada")
Tabuada()
print("Exercício 7")
Exercicio07()
print("Exercício 8")
Exercicio08()
print("Exercício 9")
Exercicio09()
print("Exercício 10")
Exercicio10()
print("Exercício 11")
Exercicio11()
print("Exercício 13")
Exercicio13()
print("Exercício 14")
Exercicio14()

class Conversao{
    
    var dolar:Double = 0.0
    var real:Double = 0.0
    
    func converte() -> Double{
        return self.dolar * self.real
        
    }
}

var conversao = Conversao()
conversao.dolar = 3.24
conversao.real = 200.01
var convertido = conversao.converte()
print("O valor de R$ \(conversao.real) convertidos pelo dólar a \(conversao.dolar) = R$ \(convertido)")

