import Foundation

//Escreva um programa para calcular e apresentar a raiz quadrada de um número carregado em uma variável.
public func Exercicio03(){
    var numQ:Double = 76.1
    var SQR = sqrt(numQ)
    
    print("A raiz quadrada de \(numQ) é \(SQR)")
}
