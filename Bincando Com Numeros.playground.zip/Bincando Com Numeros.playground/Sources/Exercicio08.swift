import Foundation

//Elabore um programa que carregue a idade de uma pessoa em uma variável, identificando sua classe eleitoral, onde:
//
//menor que 16 anos -> Não eleitor
//entre 16 e 18 anos -> Eleitor facultativo
//entre 18 e 65 anos -> Eleitor obrigatório

public func Exercicio08(){

    func calculoIdade(idade:Int){
        if (idade < 16) {
            print("Não eleitor")
        } else if (idade < 18){
            print("Eleitor facultativo")
        } else{
            print("Eleitor obrigatório")
        }
    }
    calculoIdade(idade: 15)
    calculoIdade(idade: 17)
    calculoIdade(idade: 18)
    calculoIdade(idade: 25)
}
