import Foundation

public func Tabuada(){
    
    
    for tabuada in 2...9{
        print("Tabuada do \(tabuada)")
        for numero in 1...10{
            var resultado = tabuada * numero
            print("\t\(tabuada) X \(numero) = \(resultado)")
        }
    }
}
