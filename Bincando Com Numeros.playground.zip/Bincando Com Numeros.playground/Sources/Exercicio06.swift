import Foundation

//Escreva um programa que informa se um número carregado em uma variável e informe se ele é divisível por 5.
public func Exercicio06(){
    var num:Int = 120
    var resto:Int = num%5
    if (resto == 0){
        print("O número \(num) é divisível por 5")
    }
}
