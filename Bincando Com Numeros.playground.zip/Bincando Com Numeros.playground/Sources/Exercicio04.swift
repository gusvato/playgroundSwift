import Foundation
//Escreva um programa que mostre o antecessor e o sucessor de um número inteiro carregado em uma variável.
public func Exercicio04(){
    var num = 4
    var numAnt = num - 1
    var numSuc = num + 1
    print("O número antecessor de \(num) é \(numAnt) e o sucessor é \(numSuc)")

}
