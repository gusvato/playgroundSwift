import Foundation
//Construa um programa que carregue o valor da cotação do dólar e um valor em reais em variáveis, e calcule o valor convertido para dólar.

public func Exercicio12(){
    //var url = "http://api.promasters.net.br/cotacao/v1/valores"
    //var = url.valores.USD.valor
    
//    class cotacao(){
//        //var valorDolar:Double
//        
//    }
    
}
