import Foundation
//Construa um programa que carregue o valor da cotação do dólar e um valor em reais em variáveis, e calcule o valor convertido para dólar.

public func Exercicio12(){
    class Moeda{
        var dolar = 3.21
        var real = 200.00
        
        public func converte() -> Double{
            return dolar * real
        }
    }
    
}
